﻿using CoolCast;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CoolCast {
    public class Player : Character {
        public Player( float speed, int blastRadius ) : base(speed, blastRadius) {
        }
        // Use this for initialization

        void Start() {

        }

        // Update is called once per frame
        void Update() {

        }

        public override void Move() {

        }
    }
}