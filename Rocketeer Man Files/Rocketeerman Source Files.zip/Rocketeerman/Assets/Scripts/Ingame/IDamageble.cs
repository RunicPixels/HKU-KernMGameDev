using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CoolCast {
    public interface IDamageble {

    }
}
